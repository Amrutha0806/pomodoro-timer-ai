let audioContext: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioContext) {
    audioContext = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
  }
  return audioContext;
}

type SoundType = 'bell' | 'chime' | 'ding' | 'nature' | 'default';

function playBell(ctx: AudioContext, volume: number) {
  const gainNode = ctx.createGain();
  gainNode.connect(ctx.destination);
  gainNode.gain.setValueAtTime(volume, ctx.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 2.5);

  const frequencies = [880, 1108, 1318];
  frequencies.forEach((freq, i) => {
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, ctx.currentTime + i * 0.05);
    osc.connect(gainNode);
    osc.start(ctx.currentTime + i * 0.05);
    osc.stop(ctx.currentTime + 2.5);
  });
}

function playChime(ctx: AudioContext, volume: number) {
  const notes = [523.25, 659.25, 783.99, 1046.5];
  notes.forEach((freq, i) => {
    const gainNode = ctx.createGain();
    gainNode.connect(ctx.destination);
    gainNode.gain.setValueAtTime(0, ctx.currentTime + i * 0.18);
    gainNode.gain.linearRampToValueAtTime(volume * 0.7, ctx.currentTime + i * 0.18 + 0.02);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.18 + 1.5);

    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, ctx.currentTime + i * 0.18);
    osc.connect(gainNode);
    osc.start(ctx.currentTime + i * 0.18);
    osc.stop(ctx.currentTime + i * 0.18 + 1.5);
  });
}

function playDing(ctx: AudioContext, volume: number) {
  const gainNode = ctx.createGain();
  gainNode.connect(ctx.destination);
  gainNode.gain.setValueAtTime(volume, ctx.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);

  const osc = ctx.createOscillator();
  osc.type = 'sine';
  osc.frequency.setValueAtTime(1047, ctx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.3);
  osc.connect(gainNode);
  osc.start(ctx.currentTime);
  osc.stop(ctx.currentTime + 1.2);
}

function playNature(ctx: AudioContext, volume: number) {
  // Gentle bird-like chirps
  const chirpTimes = [0, 0.3, 0.65, 1.0, 1.4];
  chirpTimes.forEach((t) => {
    const gainNode = ctx.createGain();
    gainNode.connect(ctx.destination);
    gainNode.gain.setValueAtTime(0, ctx.currentTime + t);
    gainNode.gain.linearRampToValueAtTime(volume * 0.5, ctx.currentTime + t + 0.05);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + t + 0.25);

    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1200 + Math.random() * 400, ctx.currentTime + t);
    osc.frequency.linearRampToValueAtTime(1600 + Math.random() * 300, ctx.currentTime + t + 0.1);
    osc.connect(gainNode);
    osc.start(ctx.currentTime + t);
    osc.stop(ctx.currentTime + t + 0.3);
  });
}

export async function playSound(soundName: string, volumePercent: number): Promise<void> {
  try {
    const ctx = getAudioContext();
    if (ctx.state === 'suspended') {
      await ctx.resume();
    }
    const volume = Math.max(0, Math.min(1, volumePercent / 100));
    const sound = soundName as SoundType;

    switch (sound) {
      case 'bell':
        playBell(ctx, volume);
        break;
      case 'chime':
        playChime(ctx, volume);
        break;
      case 'ding':
        playDing(ctx, volume);
        break;
      case 'nature':
        playNature(ctx, volume);
        break;
      default:
        playChime(ctx, volume);
    }
  } catch (err) {
    console.warn('Audio playback failed:', err);
  }
}
