export const motivationalMessages = [
  { emoji: '🌸', text: "You're blooming beautifully! Keep going!" },
  { emoji: '⭐', text: "Star performance! You crushed it!" },
  { emoji: '🍓', text: "Sweet success! You earned this break!" },
  { emoji: '🌈', text: "Rainbows follow the rain — and you just made sunshine!" },
  { emoji: '🦋', text: "You're transforming one Pomodoro at a time!" },
  { emoji: '🍀', text: "Lucky you — another session done!" },
  { emoji: '🌻', text: "Sunflower energy! You're growing every day!" },
  { emoji: '🎀', text: "Perfectly wrapped up! That session was a gift!" },
  { emoji: '🍰', text: "Piece of cake! You make it look easy!" },
  { emoji: '✨', text: "You're absolutely sparkling today!" },
  { emoji: '🌙', text: "Shooting for the stars — and hitting them!" },
  { emoji: '🎵', text: "You're in perfect rhythm! Keep the beat going!" },
  { emoji: '🌺', text: "In full bloom! Your focus is gorgeous!" },
  { emoji: '🍭', text: "Sweet focus! You deserve all the candy!" },
  { emoji: '🦄', text: "Magical productivity! You're one of a kind!" },
];

export function getRandomMessage() {
  return motivationalMessages[Math.floor(Math.random() * motivationalMessages.length)];
}
