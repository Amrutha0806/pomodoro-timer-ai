import React from 'react';
import { TimerConfig } from '../hooks/useTimer';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Minus, Plus } from 'lucide-react';

interface BreakSettingsProps {
  config: TimerConfig;
  onUpdate: (config: Partial<TimerConfig>) => void;
}

function DurationStepper({
  label,
  value,
  min,
  max,
  onChange,
  emoji,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (v: number) => void;
  emoji: string;
}) {
  return (
    <div className="flex items-center justify-between gap-3 p-3 bg-muted/40 rounded-2xl">
      <div className="flex items-center gap-2">
        <span className="text-xl">{emoji}</span>
        <Label className="font-bold text-sm text-foreground">{label}</Label>
      </div>
      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="icon"
          className="w-8 h-8 rounded-full"
          onClick={() => onChange(Math.max(min, value - 1))}
          disabled={value <= min}
        >
          <Minus size={14} />
        </Button>
        <span className="w-10 text-center font-bold text-foreground">{value}m</span>
        <Button
          variant="outline"
          size="icon"
          className="w-8 h-8 rounded-full"
          onClick={() => onChange(Math.min(max, value + 1))}
          disabled={value >= max}
        >
          <Plus size={14} />
        </Button>
      </div>
    </div>
  );
}

export default function BreakSettings({ config, onUpdate }: BreakSettingsProps) {
  return (
    <div className="space-y-3">
      <DurationStepper
        label="Focus Duration"
        emoji="🍅"
        value={config.focusDuration}
        min={5}
        max={90}
        onChange={(v) => onUpdate({ focusDuration: v })}
      />
      <DurationStepper
        label="Short Break"
        emoji="☕"
        value={config.shortBreakDuration}
        min={1}
        max={30}
        onChange={(v) => onUpdate({ shortBreakDuration: v })}
      />
      <DurationStepper
        label="Long Break"
        emoji="🛋️"
        value={config.longBreakDuration}
        min={5}
        max={60}
        onChange={(v) => onUpdate({ longBreakDuration: v })}
      />
      <DurationStepper
        label="Long Break Every"
        emoji="🔄"
        value={config.longBreakInterval}
        min={2}
        max={8}
        onChange={(v) => onUpdate({ longBreakInterval: v })}
      />
    </div>
  );
}
