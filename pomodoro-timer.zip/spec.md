# Specification

## Summary
**Goal:** Build "Pomo Bloom," a Pomodoro timer app with a cute pastel stationery-inspired aesthetic, task labeling, break timers, progress stats, streak gamification, reward animations, sound customization, and custom themes.

**Planned changes:**
- Implement a Pomodoro countdown timer with customizable focus duration, circular progress ring, and start/pause/reset controls
- Add automatic short break (5 min) and long break (15 min, every 4 Pomodoros) timers with visual distinction and configurable durations; user can skip breaks
- Display a prominent editable "What are you working on?" text field on the timer screen, saved with each session record
- Implement sound customization: 4+ completion sounds selectable with preview, plus a volume slider; persist preference
- Build a progress statistics dashboard showing total Pomodoros, total focus time, daily/weekly summaries, current streak, and scrollable session history with task names and dates
- Implement a streak system tracking consecutive days with at least one Pomodoro; milestone badges at 3, 7, 14, and 30-day streaks; badge collection display
- Show a gift box opening animation with sparkles/confetti and a random motivational message (10+ messages) on Pomodoro session completion; dismissible
- Add a theme picker with 5 pre-designed themes (Cherry Blossom, Mint Garden, Lavender Dream, Sunny Citrus, Midnight Stars), each with unique color palettes and decorative accents; persist selection
- Apply a cohesive pastel/stationery aesthetic (rounded cards, soft shadows, playful typography, doodle accents) consistently across all screens
- Display app logo in the header; use doodle pattern tile as decorative background accent

**User-visible outcome:** Users can run focused Pomodoro sessions with labeled tasks, enjoy automatic break transitions, track their progress and streaks with badges, celebrate completions with a gift animation, customize sounds and themes, and view their full session history on a stats dashboard — all wrapped in a cute pastel planner aesthetic.
